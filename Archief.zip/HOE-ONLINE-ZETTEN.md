# Hoe zet je deze website online?

Je hebt nu een complete werkende website in één bestand: `index.html`. Hier zijn drie manieren om hem online te krijgen, van makkelijk naar makkelijker.

## Optie 1 — Eerst even bekijken (gratis, geen account)

1. Ga naar de map `oma-milly-website` op je computer
2. Dubbelklik op `index.html`
3. Je website opent in je browser
4. Test alles: scrollen, klikken op de knoppen, FAQ openen, hardcover/softcover wisselen

Dit is alleen voor jezelf — anderen kunnen hem nog niet zien.

## Optie 2 — Online zetten via Netlify Drop (5 minuten, gratis)

Dit is verreweg de makkelijkste manier:

1. Ga naar **app.netlify.com/drop**
2. Sleep de hele map `oma-milly-website` naar het scherm
3. Wacht 30 seconden
4. Klaar! Je krijgt een URL zoals `https://random-naam-12345.netlify.app`
5. Deel deze link met iedereen

Geen account nodig om te beginnen. Wil je een eigen domein (bijv. omamilly.nl) koppelen? Maak dan een gratis account aan.

## Optie 3 — Eigen domein koppelen (€10 per jaar)

Wil je een professioneler adres zoals `omamilly.nl` of `omamillyendegrotezee.nl`?

1. Doe eerst Optie 2 (Netlify Drop) — site is dan online
2. Maak een gratis Netlify-account aan
3. Koop een domein bij **TransIP** of **Cloudflare** (€8-12/jaar)
4. In Netlify: Domain settings → Add custom domain
5. Volg de instructies om je domein te koppelen
6. Wacht 1-24 uur en je domein werkt

## Wat je nog moet aanpassen

In het HTML-bestand staan een paar dingen waar je nog naar moet kijken:

- **E-mailadres** — staat nu op `tmvangroeningen@gmail.com` (jouw adres). Klopt!
- **Prijs** — staat op €19,95 hardcover en €14,95 softcover. Pas aan in regel met `<div class="price"`
- **Bestel-knop** — opent nu een mail. Wil je echte betalingen? Vervang door een Stripe Payment Link of Mollie-link
- **Reviews** — zijn nu placeholder-reviews. Vervang door echte als je die hebt
- **Boekomslag-illustratie** — er staat nu een schildpad-emoji 🐢. Wil je je echte boekomslag gebruiken? Vervang dat in het HTML-bestand
- **Auteursfoto** — staat nu een ✍️ emoji. Vervang door een echte foto van jou

## Hulp nodig?

Vraag mij gewoon: "Hoe vervang ik de boekomslag door een echte afbeelding?" of "Hoe voeg ik een Stripe-betaalknop toe?" — dan help ik je daar stap voor stap mee.

## Echte boekafbeeldingen toevoegen

Als je echte foto's of illustraties wilt toevoegen:

1. Maak een map `images/` in dezelfde map als `index.html`
2. Zet je afbeeldingen daarin (bijv. `boekomslag.jpg`, `auteur.jpg`)
3. Vraag mij om de HTML aan te passen zodat die afbeeldingen gebruikt worden

Veel plezier met je website!
